changement du Global.css avec le background-color du body qui etait en bleu en blanc 

création des pages avec l'ajout de la barre avec tout les liens cliquable 

Suite a ces pages la je les ai ajouté a index.html pour que cela soit cliquable et que ça ramene a une vrai page car aucune marchait a part 

Mise en page de Introduction dans css